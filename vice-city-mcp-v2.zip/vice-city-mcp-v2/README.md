
# Vice City Rules MCP — V2

MCP focado em consultar a documentação oficial do Vice City (Lotus Group).

## Princípio

A fonte de verdade é:

https://www.regraslotusgroup.com.br/vice

O crawler começa em `/vice` e percorre recursivamente links do mesmo domínio dentro de `/vice`. Ele salva cada página integralmente em `data/pages/`, mantendo título, texto, seções e URL.

Isso evita depender de uma lista manual de regras.

## Ferramentas MCP

- `consultar_regra(pergunta)` — pesquisa as páginas indexadas e devolve evidências + fonte.
- `verificar_acao(situacao)` — recupera as regras relevantes para uma situação e exige decisão conservadora quando faltar regra explícita.
- `atualizar_regras()` — refaz o crawl completo.
- `status_regras()` — mostra quantidade/data/erros.

## Importante sobre "100%"

O servidor foi desenhado para **não resumir o site na mão**. Porém, "100% baseado nas regras" só é seguro se a atualização estiver funcionando e se o site não esconder conteúdo atrás de login/JavaScript inacessível ao crawler.

Por isso cada resultado inclui a URL da página fonte, e `atualizar_regras()` deve ser executado sempre que quiser conferir a versão atual.

## Instalação

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
python server.py
```

O servidor usa Streamable HTTP.

## Docker

```bash
docker build -t vice-city-mcp .
docker run -p 8000:8000 vice-city-mcp
```

Endpoint típico:

`http://localhost:8000/mcp`

Para conectar de fora, publique atrás de HTTPS e autenticação. Não exponha um servidor sem proteção em produção.

## Deploy

`render.yaml` é um ponto de partida para Render. Você também pode usar qualquer host que aceite Docker/Python e HTTPS.

## Operação recomendada

1. Subir o servidor.
2. Chamar `atualizar_regras()`.
3. Conferir `status_regras()`.
4. Usar `consultar_regra()` para perguntas.
5. Usar `verificar_acao()` para situações.

## Limite importante

Este MCP não deve inventar punições ou permissões. Se a regra não for encontrada, deve dizer que não há regra expressa encontrada.
