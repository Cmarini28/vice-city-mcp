
import hashlib, json, re, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag

import requests
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP

BASE = "https://www.regraslotusgroup.com.br/vice"
HOST = "www.regraslotusgroup.com.br"
ROOT = Path(__file__).parent
DATA = ROOT / "data"
PAGES = DATA / "pages"
INDEX = DATA / "index.json"
HEADERS = {"User-Agent": "ViceCity-Ilegal-MCP/2.0 (+documentation crawler)"}

mcp = FastMCP("vice-city-regras")

def canonical(url):
    url, _ = urldefrag(url)
    p = urlparse(url)
    if p.scheme not in ("http","https") or p.netloc != HOST:
        return None
    path = p.path.rstrip("/")
    if not path.startswith("/vice"):
        return None
    return f"https://{HOST}{path or '/vice'}"

def load_index():
    if INDEX.exists():
        return json.loads(INDEX.read_text(encoding="utf-8"))
    return {"server":"Vice City","source":BASE,"updated_at":None,"pages":[]}

def save_index(x):
    DATA.mkdir(exist_ok=True)
    INDEX.write_text(json.dumps(x, ensure_ascii=False, indent=2), encoding="utf-8")

def page_path(url):
    h = hashlib.sha256(url.encode()).hexdigest()[:24]
    return PAGES / f"{h}.json"

def fetch(url):
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    return r.text, r.url

def parse(url, html):
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else url
    main = soup.find("main") or soup
    text = main.get_text("\n", strip=True)
    links = []
    for a in main.find_all("a", href=True):
        u = canonical(urljoin(url, a["href"]))
        if u and u not in links:
            links.append(u)
    # Preserve headings/list structure separately for retrieval.
    sections = []
    current = None
    for node in main.find_all(["h1","h2","h3","h4","p","li"]):
        t = node.get_text(" ", strip=True)
        if not t: continue
        if node.name.startswith("h"):
            current = {"heading": t, "items":[]}
            sections.append(current)
        elif current:
            current["items"].append(t)
    return {"url":url,"title":title,"text":text,"sections":sections,"links":links}

def crawl():
    DATA.mkdir(exist_ok=True); PAGES.mkdir(exist_ok=True)
    queue=[BASE]; seen=set(); pages=[]; errors=[]
    while queue:
        url=queue.pop(0)
        if url in seen: continue
        seen.add(url)
        try:
            html, final = fetch(url)
            cu=canonical(final) or url
            doc=parse(cu, html)
            out=page_path(cu)
            out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
            pages.append({"url":cu,"title":doc["title"],"file":str(out.relative_to(DATA))})
            for link in doc["links"]:
                if link not in seen and link not in queue:
                    queue.append(link)
        except Exception as e:
            errors.append({"url":url,"error":str(e)})
    idx={"server":"Vice City","source":BASE,
         "updated_at":datetime.now(timezone.utc).isoformat(),
         "page_count":len(pages),"pages":pages,"errors":errors}
    save_index(idx)
    return idx

def ensure_index():
    idx=load_index()
    if not idx["pages"]:
        idx=crawl()
    return idx

def tokenize(s):
    return set(re.findall(r"[a-z0-9áéíóúãõâêôçü]+", s.lower()))

STOP=set("a o os as de do da dos das e em no na nos nas para por com sem que um uma uns umas é ser são pode posso posso fazer como eu você me se ao aos às ou".split())

def search(query, limit=8):
    idx=ensure_index()
    q={x for x in tokenize(query) if x not in STOP and len(x)>2}
    scored=[]
    for p in idx["pages"]:
        doc=json.loads((DATA/p["file"]).read_text(encoding="utf-8"))
        blob=(doc["title"]+" "+doc["text"]).lower()
        hits=sum(1 for t in q if t in blob)
        exact=sum(2 for t in q if (" "+t+" ") in (" "+blob+" "))
        score=hits+exact
        if score: scored.append((score,doc))
    scored.sort(key=lambda x:x[0], reverse=True)
    return [d for _,d in scored[:limit]]

@mcp.tool()
def consultar_regra(pergunta: str) -> str:
    """Pesquisa TODAS as páginas indexadas do regulamento oficial. Responde com trechos curtos e URLs."""
    docs=search(pergunta, 8)
    if not docs:
        return "⚠️ NÃO ENCONTRADO NA BASE. Não assumir que é permitido. Execute atualizar_regras() e/ou confirme na administração."
    out=["📚 RESULTADO — VICE CITY"]
    for d in docs[:5]:
        # Extract lines containing query terms, keeping context.
        qs=[x for x in tokenize(pergunta) if x not in STOP and len(x)>2]
        lines=d["text"].splitlines()
        hits=[]
        for i,line in enumerate(lines):
            low=line.lower()
            if sum(t in low for t in qs)>=1:
                hits.extend(lines[max(0,i-1):min(len(lines),i+2)])
        seen=set(); snippet=[]
        for x in hits:
            if x not in seen:
                seen.add(x); snippet.append(x)
            if len(snippet)>=8: break
        out.append(f"\n## {d['title']}\n" + "\n".join(f"• {x}" for x in snippet))
        out.append(f"Fonte: {d['url']}")
    return "\n".join(out)

@mcp.tool()
def verificar_acao(situacao: str) -> str:
    """Analisa a situação contra o conjunto de regras indexadas.
    Importante: é uma triagem baseada no texto oficial, não inventa permissões.
    """
    docs=search(situacao, 12)
    if not docs:
        return "⚠️ NÃO HÁ REGRA ENCONTRADA. Não considerar automaticamente permitido."
    # Conservative: retrieve evidence, but do not fabricate a yes/no when facts are insufficient.
    out=["🔎 ANÁLISE BASEADA NO REGULAMENTO OFICIAL",""]
    out.append("⚠️ A decisão depende da combinação dos fatos informados com as regras abaixo:")
    for d in docs[:6]:
        out.append(f"\n[{d['title']}]")
        terms=[x for x in tokenize(situacao) if x not in STOP and len(x)>2]
        lines=d["text"].splitlines()
        picked=[]
        for i,l in enumerate(lines):
            if any(t in l.lower() for t in terms):
                picked.extend(lines[max(0,i-1):min(len(lines),i+2)])
        uniq=[]
        for x in picked:
            if x not in uniq: uniq.append(x)
        for x in uniq[:5]: out.append(f"• {x}")
        out.append(f"Fonte: {d['url']}")
    out.append("\n⚠️ Se não houver regra expressa para algum ponto, não presumir que é permitido.")
    return "\n".join(out)

@mcp.tool()
def atualizar_regras() -> str:
    """Recrawla todas as páginas do Vice City dentro de /vice e substitui o índice."""
    idx=crawl()
    return f"✅ Atualizado. {idx['page_count']} páginas indexadas. " + (
        f"⚠️ {len(idx['errors'])} páginas com erro." if idx["errors"] else "Nenhum erro."
    )

@mcp.tool()
def status_regras() -> str:
    idx=load_index()
    return f"Vice City | páginas: {idx.get('page_count',0)} | atualização: {idx.get('updated_at')} | erros: {len(idx.get('errors',[]))}"

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
